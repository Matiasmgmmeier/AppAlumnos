package com.example.appalumnos.Entidades

data class Student(
 val Id : Int,
 val Name: String,
 val Age: Int,
 val PictureUrl: String,
)




